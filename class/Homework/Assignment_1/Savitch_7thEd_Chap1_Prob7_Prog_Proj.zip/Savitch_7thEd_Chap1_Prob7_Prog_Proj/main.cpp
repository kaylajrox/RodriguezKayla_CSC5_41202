/* 
 * Author: Kayla Rodriguez
 * Created on January 6, 2016, 9:38 AM
 * Purpose: Computer Science is Cool Stuff
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constant

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {
    //Declare and initialize variables
    
    
    //Inputs 
    
    //Calculate 
    
    //Output the results
    cout<<"*****************************************************\n";
    cout<<"                                                     \n";
    cout<<"                                                     \n";
    cout<<"         C C C              S S S             !!     \n";
    cout<<"       C      C           S       S           !!     \n";
    cout<<"      C                  S                    !!     \n";
    cout<<"     C                  S                     !!     \n";
    cout<<"     C                   S                    !!     \n";
    cout<<"     C                     S S S S            !!     \n";
    cout<<"      C                           S           !!     \n";
    cout<<"       C                           S                 \n";
    cout<<"        C       C                 S                  \n";
    cout<<"          C C C           S S S S             00     \n";
    cout<<"                                                     \n";
    cout<<"*****************************************************\n";
    cout<<"      Computer Science is Cool Stuff!!!                ";
    cout<<"                                                     \n";
    
    
    //Exit stage right
    return 0;
}